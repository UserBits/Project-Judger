#include <cstdio>
using namespace std;
int main()
{
	freopen("packets.in","r",stdin);
	freopen("packets.out","w",stdout);
	int t1,t2,t3,t4,t5,t6,ans,tmp1,tmp2,array[4]={0,5,3,1},t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d%d%d%d%d",&t1,&t2,&t3,&t4,&t5,&t6);
		ans=t6+t5+t4+(t3+3)/4;
		tmp2=5*t4+array[t3%4];
		if(t2>tmp2)
			ans+=(t2-tmp2+8)/9;
		tmp1=36*(ans-t6)-25*t5-16*t4-9*t3-4*t2;
		if(t1>tmp1)
			ans+=(t1-tmp1+35)/36;
		printf("%d\n",ans);
	}
	//while(1);
	return 0;
}

